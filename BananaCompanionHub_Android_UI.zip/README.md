# Banana-inspired Blox Fruits Companion Hub (Android-friendly UI)

This is a safe Roblox Studio UI prototype inspired by Banana Hub's dark/yellow look.
It is **not** a Banana Hub copy and is **not** an exploit script.

## Included
- Touch/mouse draggable panel
- Farm, Utility, Raid, and Settings tabs
- Quest and raid checklists
- Manual fruit-search reminders
- Clear notices that Auto Farm, ESP, and unauthorized teleport are not implemented

## Install in Roblox Studio
1. Open a Roblox Studio place you own.
2. In Explorer, open `StarterPlayer` > `StarterPlayerScripts`.
3. Insert a `LocalScript`.
4. Paste the contents of `BananaCompanionHub.lua`.
5. Press **Play** to test. Use the emulator/device preview to check the phone layout.

## Android note
This is a LocalScript for a place you control, tested through Roblox Studio. You cannot normally install arbitrary Lua scripts into the official Roblox Android client. Do not enter your Roblox password into third-party executors or download unknown APKs.

## Scope
The UI does not automate combat or quests, reveal hidden entities, modify game state, or invoke remote events. To add actual game features, implement them in a Roblox experience you own using documented game systems and server-side validation.
